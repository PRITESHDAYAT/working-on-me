
# Jewelry Segment Classifier App (Local)

## Setup Instructions (One-Time)
1. Open Command Prompt
2. Navigate to this folder:
   cd path\to\unzipped\folder

3. Create virtual environment (optional but recommended)
   python -m venv env
   env\Scripts\activate

4. Install required libraries:
   pip install torch torchvision transformers streamlit Pillow

## Run the App
streamlit run jewelry_segment_app.py

Then open the local browser link (usually http://localhost:8501)

Upload a jewelry image → It will show matching segments like "Modern", "Temple", "Office Wear", etc.
